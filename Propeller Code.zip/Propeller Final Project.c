/*
  Welcome.c
  
  Welcome to SimpleIDE, the C programming environment that makes it easy to 
  get started with the multi-core Propeller microcontroller! 
  
  To run this program:
  
    - Is this the first Parallax software you've installed on your computer?  
      If so, install USB driver's now: www.parallax.com/usbdrivers
    - Connect your Propeller board to your computer's USB.  Also connect power
      to the board if needed, and if it has a power switch, turn it on.
    - Make sure to select your COM port from the toolbar dropdown menu in the
      upper-right corner.  If you are unsure which COM port your board is 
      connected to, disconnect it and click the dropdown to check the port 
      list, then reconnect it and check again.
    - Click Program and select Run with Terminal (or click the Run with Terminal 
      button).  The SimpleIDE Terminal should appear and display the "Hello!"
      message.
      
   Next, check the Help menu for new online tutorials, software manual, and 
   reference material.
   http://learn.parallax.com/propeller-c-tutorials
*/

#include "simpletools.h"                      // Include simple tools
//For ADC
const int CS = 2;
const int CLK = 3;
const int DataPin = 4;
//For Cogs
static volatile int dB;
static volatile int Raw;
static volatile int TableNo=1;
static volatile int Threshold = 50;
static volatile int Occupancy;
static volatile int Avg;
//static volatile int SerialCheck;
static volatile int WiFiAvg;
static volatile int SendingData;
unsigned int stack1[40+30];
unsigned int stack2[40+30];
unsigned int stack3[40+30];
unsigned int stack4[40+30];
unsigned int stack5[40+30];
unsigned int stack6[40+30];
unsigned int stack7[40+30];
void ARead(void *par1);
void dBCalc(void *par2);
void AvgCalculation(void *par3);
void LED(void *par4);
void TableButtons(void *par5);
void PotRead(void *par6);
void DatatoWiFi(void *par7);
//Ping Pin
const int SigPin = 12;
//LCD
const int ON = 22;
const int CLR = 12;
const int CRT = 13;
serial *lcd;
//Wifi
const int Rx = 14;
const int Tx = 15;
serial *wifi;
//LED
const int redPin = 8;
const int greenPin = 9;
const int bluePin = 10;
//6 and 7 pins are for buttons


int main()                                    // Main function//COG 0
{
  cogstart(&ARead, NULL, stack1, sizeof(stack1));
  cogstart(&dBCalc, NULL, stack2, sizeof(stack2));
  cogstart(&AvgCalculation, NULL, stack3, sizeof(stack3));
  cogstart(&LED, NULL, stack4, sizeof(stack4));
  cogstart(&TableButtons, NULL, stack5, sizeof(stack5));
  cogstart(&PotRead, NULL, stack6, sizeof(stack6));
  cogstart(&DatatoWiFi, NULL, stack7, sizeof(stack7));
  
  
  while(1){
   
      printf("Current dB: %d Avg: %d Table No: %d Threshold: %d WiFiAvg: %d Sending: %d Occ: %d\n",dB,Avg,TableNo,Threshold,WiFiAvg,SendingData,Occupancy);//Printing to Serial Terminal
      
    pause(100);
    
}
}    


void ARead(void *par1)// COG 1 // Reading from ADC 0831
{
   int sum = 0;
  set_direction(CS,1);
  set_direction(CLK,1);
  set_direction(DataPin,0);
  
  while(1)
  {
    sum = 0;
    for(int i = 0; i<256; i++)
    {
    sum = Analog_read() + sum;
  }    
  Raw = sum/256;
  }
}
  
int Analog_read()
{
  int  adcbits=0;
    high(CS);
    low(CS);
    high(CLK);
    low(CLK);
    for(int i=0; i<=7; i++) 
    {
      high(CLK);
      low(CLK);
      adcbits = adcbits*2;
      int Data = input(DataPin);
      adcbits=adcbits+Data;
    }
    return adcbits;
  }    
  

void dBCalc(void *par2)// COG 2//dB Calculation
{
   int cm = 0;
  while(1)
  {
   

  cm =  ping_cm(SigPin);
  if(cm>40)
  {
    Occupancy = 0;
  }
  else if(cm<40)
  {
    Occupancy = 1;
  }   
    
  dB = 30+(Raw*110)/256.0;
  pause(50);
}
}
void AvgCalculation(void *par3)//COG 3//Avg Calculation for every second
{
  int timer = 0;
  int Temp = 0;
  while(1)
  {
    if(timer > 100)
    {
      Avg = Temp/timer;
      timer = 0;
      Temp = 0;
      
    }
    pause(10);
    timer +=1;
    Temp = Temp + dB;
  }    
}  

void LED(void *par4)//COG 4// Turning the LED on if the dB value exceeds threshold
{
  set_direction(bluePin,1);
  set_direction(greenPin,1);
  set_direction(redPin,1);
  while(1)
  {
    
  if(Avg > Threshold)
  {
    low(bluePin);
   // SendtoWiFi = 1;
  }
  else
  {
    LedReset();
  }    
}     
}      

void TableButtons(void *par5)//COG 5// Getting input from up and down buttons for table selection
{
    while(1)
    {
      if(input(6))
      {
        TableNo +=1;
      }
      while(input(6))
      {
      }
      if(input(7))
      {
        if(TableNo > 1)
        {
        TableNo -=1;
      }else{
        TableNo = 1;        
      }
    }      
      while(input(7))
      {
      }                
    }      
}    

         

void LedReset()// Turning Anode tri-color LED OFF
{
  high(bluePin);
  high(greenPin);
  high(redPin);;
}

void PotRead(void *par6)//COG 6 // Reading value from Potentiometer using In-built I2C ADC for setting dB treshold value
{
  int ack; //acknowledgement received from ADC chip 
 unsigned long int adc_h=0; //adc high byte check table no 13 
 unsigned long adc_l=0; //adc low byte
  unsigned long int adc_result=0; 
  float adc_volts=0; 
  i2c adc_bus; // declare i2c bus structure variable 
  i2c_open(&adc_bus, 28, 29, 0); //28:scl, 29:sda, 0: no scl drive since external pullup available // on the hardware 
  while(1)
  {
    ack = i2c_poll(&adc_bus,0b01000110); //check fig 33 mode 2 operation // (send 7 bit address + one bit W(0))
    if(ack==0)  {
       ack=i2c_writeByte(&adc_bus,0b00010000); //check table 27 to write into pointer register, // high nib indicates channel to read //x  x  x  x  0  0  0  0 //c4 c3 c2 c1 p3 p2 p1 p0 // (c channel p pointer register) 
    
      if(ack==0) {
        
          pause(100); 
          ack = i2c_poll(&adc_bus,0b01000111);//check table no 6 for address config as // =gnd ad7993-0 //first 7 bit from table 6 and // lsb=1 (for read opeartion)     
          if(ack==0) {
            
            adc_h=i2c_readByte(&adc_bus,0); //see table 13, Low nibble contains // MSB-B8 of ADC Data
            
            adc_l=i2c_readByte(&adc_bus,1);  //see table 13, High 6 bits contain b7 to b2 //MSB TO B8 and B7 TO B2=10 Bit ADC Data
            
            adc_result=((adc_h & 0b00001111) << 6) | (adc_l >> 2) ;   
           
            Threshold=((float)(adc_result) * (140))/ (float)1023.0; 
            
             } 
          } 
               
         } 
                 pause(500); 
     }//end of while(1) 

  
}  

void DatatoWiFi(void *par7)//COG 7 // using Serial Port to send data to both LCD and WiFi Module
{
  int WifiTimer = 0;
  int WifiTemp=0;
  while(1)
  {
    LCDFunc();
    if(WifiTimer>2)// Data is send once every 0.2 seconds to the WiFi Module but thingSpeak server only allows 1 message every 15 econds
    {
      WiFiAvg = WifiTemp/WifiTimer;
      SendingData = 1;  
        wifi = serial_open(Tx,Rx,0,9600);
       dprint(wifi,"%d;%d;%d;%d\n",TableNo,WiFiAvg,Threshold,Occupancy);
       
       serial_close(wifi);
      WifiTimer = 0;
      WifiTemp = 0;
    }  
            
    pause(100);
    WifiTimer +=1;
    WifiTemp = WifiTemp + dB;
    SendingData = 0;
  }    
  
}  



int ping(int pin) { 
low(pin); 
pulse_out(pin, 10); 
return pulse_in(pin, 1); 
}
int ping_cm(int pin) {
   long tEcho = ping(pin);
    int cmDist = tEcho / 58; 
    return cmDist;
     }

  /*
  int SerialReady = 0;
    lcd = serial_open(13,13,0,9600);
  
  while(1)
  {
    if(SerialCheck ==1)
    {
      serial_close(lcd);
      SerialCheck = 2;
    }
    while(SerialCheck != 0)
    {
      SerialReady = 1;
    }//Wait until Serial port on wifi module closes
    if(SerialReady ==1)
    {
      lcd = serial_open(13,13,0,9600);
      SerialReady =0;
    }          
     lcd = serial_open(13,13,0,9600);        
    writeChar(lcd,ON);
    writeChar(lcd,CLR);
    writeChar(lcd, 128);
    dprint(lcd,"Tb No: %d Avg: %d",TableNo,Avg);
    writeChar(lcd, 148);
    dprint(lcd,"Cu: %d Th: %d",dB,Threshold);
    pause(100);
  }
  
    serial_close(lcd);*/
  
     

void LCDFunc()
{
  lcd = serial_open(13,13,0,9600);        
    writeChar(lcd,ON);
    writeChar(lcd,CLR);
    writeChar(lcd, 128);
    dprint(lcd,"TbNo:%d Avg:%d",TableNo,Avg);
    writeChar(lcd, 148);
    dprint(lcd,"Cu: %d Th: %d",dB,Threshold);
    pause(100);
    serial_close(lcd);
  }    